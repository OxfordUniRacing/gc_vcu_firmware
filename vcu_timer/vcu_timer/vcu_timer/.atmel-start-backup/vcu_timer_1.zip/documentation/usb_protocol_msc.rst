================
USB MSC Protocol
================

USB MSC Protocol is a part of the USB Device Stack library. It provides basic
macro definitions and data structures which are compliant with Mass Storage
Control/Bulk/Interrupt (CBI) Specification 1.1 and Mass Storage UFI Command
Specification 1.0.


Applications
------------

N/A

Dependencies
------------

N/A


Limitations
-----------

N/A
